﻿using System;
namespace CalculatorModelLibrary
{
	public class Calculator
	{
		public Calculator()
		{
		}
		public int add(int param1, int param2)
		{ 	
			return param1 + param2;
		}
		public int sub(int param1, int param2)
		{
			return param1 - param2;
		}
		public int mul(int param1, int param2)
		{
			return param1 * param2;
		}
		public int div(int param1, int param2)
		{
			float div = param1 / param2;
			return (int)Math.Round(div);
		}
	}
}

