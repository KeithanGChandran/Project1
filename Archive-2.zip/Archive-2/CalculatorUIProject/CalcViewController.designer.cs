// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace CalculatorUIProject
{
    [Register ("CalcViewController")]
    partial class CalcViewController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton ButtonCalculate { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel LabelResult { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UISegmentedControl SegmentOP { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField TextNumberOne { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField TextNumberTwo { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (ButtonCalculate != null) {
                ButtonCalculate.Dispose ();
                ButtonCalculate = null;
            }

            if (LabelResult != null) {
                LabelResult.Dispose ();
                LabelResult = null;
            }

            if (SegmentOP != null) {
                SegmentOP.Dispose ();
                SegmentOP = null;
            }

            if (TextNumberOne != null) {
                TextNumberOne.Dispose ();
                TextNumberOne = null;
            }

            if (TextNumberTwo != null) {
                TextNumberTwo.Dispose ();
                TextNumberTwo = null;
            }
        }
    }
}