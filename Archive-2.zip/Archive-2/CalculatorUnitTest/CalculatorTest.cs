﻿
using System;
using NUnit.Framework;

using CalculatorModelLibrary;

namespace CalculatorUnitTest
{
	[TestFixture]
	public class CalculatorTest
	{
		private Calculator calc = new Calculator();

		[Test]
		public void TestAddition() {
			Assert.True(calc.add(3, 5) == 8);
			Assert.True(calc.add(4, 18) == 22);           
	}
		[Test]
		public void TestSubtraction()
		{
			Assert.True(calc.sub(13, 5) == 8);
			Assert.True(calc.sub(34, 18) == 20);
		}
		[Test]
		public void TestMultipolcation()
		{
			Assert.True(calc.mul(3, 5) == 15);
			Assert.True(calc.mul(4, 6) == 24);
		}
		[Test]
		public void TestDivision()
		{
			Assert.True(calc.div(13, 5) == 2);
			Assert.True(calc.div(40, 4) == 10);
		}	
	}
}
