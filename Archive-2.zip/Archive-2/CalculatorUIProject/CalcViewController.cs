using Foundation;
using System;
using UIKit;
using CalculatorModelLibrary;

namespace CalculatorUIProject
{
    public partial class CalcViewController : UIViewController
    {
        public CalcViewController (IntPtr handle) : base (handle)
        {
        }

		private Calculator calc = new Calculator();


		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			ButtonCalculate.TouchUpInside += (o, e) =>
			{

				int num1 = Convert.ToInt32(TextNumberOne.Text);
				int num2 = Convert.ToInt32(TextNumberTwo.Text);
				int result;
				float div = num1 / num2;

				switch (SegmentOP.SelectedSegment)
				{
					case 0:
						result = calc.add(num1, num2);
						break;
					case 1:
						result = calc.sub(num1, num2);
						break;
					case 2:
						result = calc.mul(num1, num2);
						break;
					case 3:
						result = (int)Math.Round(div);
						break;
					default:
						result = num1 + num2;
						break;
				}

				LabelResult.Text = Convert.ToString(result);

			};
			// Perform any additional setup after loading the view, typically from a nib.
		}

		public override void DidReceiveMemoryWarning()
		{
			base.DidReceiveMemoryWarning();
			// Release any cached data, images, etc that aren't in use.
		}
    }
}